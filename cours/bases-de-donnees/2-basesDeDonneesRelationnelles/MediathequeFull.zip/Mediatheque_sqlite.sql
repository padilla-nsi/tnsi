.open "MEDIATHEQUE";

CREATE TABLE "LIVRE" (
  "isbn" VARCHAR(42),
  "titre" VARCHAR(42),
  "editeur" VARCHAR(42),
  "annee" VARCHAR(42),
  PRIMARY KEY ("isbn")
);

CREATE TABLE "AUTEUR_DE" (
  "#a_id" VARCHAR(42),
  "#isbn" VARCHAR(42),
  PRIMARY KEY ("#a_id", "#isbn")
);

CREATE TABLE "AUTEUR" (
  "a_id" VARCHAR(42),
  "nom" VARCHAR(42),
  "prenom" VARCHAR(42),
  PRIMARY KEY ("a_id")
);

CREATE TABLE "EMPRUNT" (
  "#code_barre" VARCHAR(42),
  "#isbn" VARCHAR(42),
  PRIMARY KEY ("#code_barre", "#isbn")
);

CREATE TABLE "USAGER" (
  "code_barre" VARCHAR(42),
  "nom" VARCHAR(42),
  "prenom" VARCHAR(42),
  "adresse" VARCHAR(42),
  "cp" VARCHAR(42),
  "ville" VARCHAR(42),
  "email" VARCHAR(42),
  PRIMARY KEY ("code_barre")
);